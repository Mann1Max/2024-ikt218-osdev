

extern "C" int kernel_main(void);
int kernel_main(){
    return 0;
}