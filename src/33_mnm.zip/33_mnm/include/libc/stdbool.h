#pragma once 

#define bool unsigned char
#define true 1
#define false 0
