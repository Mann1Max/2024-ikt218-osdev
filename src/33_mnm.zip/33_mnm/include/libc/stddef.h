#pragma once

#define NULL ((void*)0)