#pragma once
#include "./stdint.h"

size_t strlen(const char* str);